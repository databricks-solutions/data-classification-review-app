from pathlib import Path

app_name = "data-classification-review-app"
app_entrypoint = "data_classification_review_app.backend.app:app"
app_slug = "data_classification_review_app"
api_prefix = "/api"
dist_dir = Path(__file__).parent / "__dist__"